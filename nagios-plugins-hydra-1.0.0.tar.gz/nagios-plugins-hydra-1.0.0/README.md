Nagios plugins for EMI Hydra
==============================

General Information
-------------------
These probes work exclusively for EMI Hydra

Documentation
-------------
The complete documentation of the probes can be found online:
    https://twiki.cern.ch/twiki/bin/view/EMI/EMIHydraDocumentation


Installation
------------
Just type make install in the same directory as this README file can be found
